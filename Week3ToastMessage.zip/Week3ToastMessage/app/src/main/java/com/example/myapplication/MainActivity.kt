package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Bind the components to their respective objects by assigning
        // their IDs with the help of findViewById() method
        val btn = findViewById<Button>(R.id.Button01)
        btn.setOnClickListener { // Displaying simple Toast message
            Toast.makeText(applicationContext, "This a toast message", Toast.LENGTH_LONG).show()
        }
    }
}
